# Output Screenshots and Demo Video

## Screenshots to Capture
Capture these from the running StaffSync app; do not fabricate them.

1. Login page.
2. Dashboard after successful login.
3. Employee directory/search (use an account/role with access).
4. Attendance check-in/check-out or attendance history.
5. Leave request form and/or review queue.
6. Announcements page.
7. Training programme list and enrolment.
8. Any role-specific view that is actually implemented and accessible.

Save images in `docs/screenshots/` with descriptive names such as `01-login.png`, `02-dashboard.png`, `03-employees.png`, and so on. Remove or obscure personal data, tokens, email addresses that should not be public, and all secrets before committing screenshots.

## Suggested 2–4 Minute Demo Script
- **0:00–0:20 — Introduction:** “This is StaffSync, a Human Resource Management System designed to bring employee and HR workflows into one web application.”
- **0:20–0:45 — Login/dashboard:** Sign in with a valid demo account and show the dashboard.
- **0:45–1:15 — Employees:** Show employee search or profile management, if available for the role.
- **1:15–1:45 — Attendance:** Demonstrate check-in/out or attendance history.
- **1:45–2:15 — Leave:** Show a leave request and, if available, the review process using an authorized role.
- **2:15–2:40 — Announcements and training:** Show published announcements and training enrolment/programmes.
- **2:40–3:00 — Technical summary:** Briefly mention React, TypeScript, Express, MongoDB, and Mongoose.

Only demonstrate features that work in the current build. Do not show environment files, database credentials, JWTs, developer tools containing secrets, or real personal records.

## Video File
Save the recording as `StaffSync-Demo.mp4`. If it is too large for the repository, upload it to an approved video hosting location and add the share link to the main README. Confirm the link permissions before submission.
